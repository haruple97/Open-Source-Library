package com.haruple97.expandablerecyclerview_opensource;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    private RecyclerView recyclerview;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        recyclerview = findViewById(R.id.recyclerview);
        recyclerview.setLayoutManager(new LinearLayoutManager(this, LinearLayoutManager.VERTICAL, false));
        List<ExpandableListAdapter.Item> data = new ArrayList<>();

        data.add(new ExpandableListAdapter.Item(ExpandableListAdapter.HEADER, "모험가 마법사"));
        data.add(new ExpandableListAdapter.Item(ExpandableListAdapter.CHILD, "썬콜"));
        data.add(new ExpandableListAdapter.Item(ExpandableListAdapter.CHILD, "불독"));
        data.add(new ExpandableListAdapter.Item(ExpandableListAdapter.CHILD, "바숍"));

        data.add(new ExpandableListAdapter.Item(ExpandableListAdapter.HEADER, "레지스탕스"));
        data.add(new ExpandableListAdapter.Item(ExpandableListAdapter.CHILD, "메카닉"));
        data.add(new ExpandableListAdapter.Item(ExpandableListAdapter.CHILD, "배틀메이지"));
        data.add(new ExpandableListAdapter.Item(ExpandableListAdapter.CHILD, "와일드헌터"));
        data.add(new ExpandableListAdapter.Item(ExpandableListAdapter.CHILD, "블래스터"));

        ExpandableListAdapter.Item places = new ExpandableListAdapter.Item(ExpandableListAdapter.HEADER, "노바");
        places.invisibleChildren = new ArrayList<>();
        places.invisibleChildren.add(new ExpandableListAdapter.Item(ExpandableListAdapter.CHILD, "카이저"));
        places.invisibleChildren.add(new ExpandableListAdapter.Item(ExpandableListAdapter.CHILD, "카인"));
        places.invisibleChildren.add(new ExpandableListAdapter.Item(ExpandableListAdapter.CHILD, "카데나"));
        places.invisibleChildren.add(new ExpandableListAdapter.Item(ExpandableListAdapter.CHILD, "엔젤릭버스터"));

        data.add(places);

        recyclerview.setAdapter(new ExpandableListAdapter(data));

    }
}