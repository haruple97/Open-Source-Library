package org.donghwan.sharedprederences_opensource;

import androidx.appcompat.app.AppCompatActivity;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {

    EditText et_save;
    String shared = "file";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        et_save = (EditText)findViewById(R.id.et_save);

        SharedPreferences sharedPreferences = getSharedPreferences(shared, 0);
        String value = sharedPreferences.getString("haruple", "");
        //꺼내오는거기 때문에 두번째 인자는 빈 값
        et_save.setText(value);

    }

    @Override
    protected void onDestroy() {
        super.onDestroy(); //Activity 벗어났을 때 파괴됨.

        //SharedPreferences 실행하면서 나갈 수 있게
        SharedPreferences sharedPreferences = getSharedPreferences(shared, 0);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        //저장할 때 Editor를 불러와야함. editor와 sharedPreferences 연결함.

        String value = et_save.getText().toString();
        //입력한 값을 value에 받아옴.
        editor.putString("haruple",value);
        // 두가지 인자가 넣어줄건데 하나는 아무거나 넣고, value 같이
        editor.commit();

    }
}